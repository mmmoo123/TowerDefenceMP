package images;

public enum Image {
	MAPA,IKONA,B1,B2,B3,T1,T2,T3,YouLose,InterfaceBackground;
}
